# Biography

> Updated May 2023

- Basic Information
    - ![Photo](./media/ID.jpg)
    - Gender:Male
    - Date of birth:1997.11.28
    - Contact
        - E-mail:<ganghuic@stu.xju.edu.cn>

    - Link
        - Website:<https://connerphlip.github.io>
        - GitHub:<https://github.com/connerphlip>
        - Bilibili:<https://space.bilibili.com/296055667>


# Welcome

This is Ganghui Cao's Blog <https://connerphlip.github.io>

- 通过主题和目录以打开文章
    - PC端 在上方标签栏选择主题 在左侧目录选择文章
    - 移动端 点击左上角图标选择主题和文章
- 搜索关键词以打开文章
